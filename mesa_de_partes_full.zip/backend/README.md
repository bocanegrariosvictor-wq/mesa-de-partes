# Backend - Mesa de Partes (full demo)

Este backend usa SQLite para facilitar una prueba local rápida.

Pasos para ejecutar:
1. Instalar dependencias: `cd backend && npm install`
2. Copiar `.env.example` a `.env` y ajustar si deseas.
3. Ejecutar: `npm run dev` (requiere nodemon) o `npm start`

Credenciales demo creadas automáticamente:
- admin@demo.local / admin123
