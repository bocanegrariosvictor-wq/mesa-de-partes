# Frontend - Mesa de Partes (full demo)

Pasos para ejecutar:
1. cd frontend
2. npm install
3. npm run dev

Asegúrate que el backend esté corriendo en http://localhost:4000 o ajusta VITE_API_URL.
